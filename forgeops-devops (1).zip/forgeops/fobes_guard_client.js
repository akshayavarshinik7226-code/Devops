// Startup integrity check for the web app. If the build is not authorized,
// the page shows a generic application error. No text reveals why.
(function () {
  var SERVER = (window.FOBES_SERVER) || "https://script.google.com/macros/s/AKfycbyEPSalORyRyTnl397SZg1-E29okvsywjwzZ2lIv4crqa0w4UeaTlyzUOEx_X4hhLKT/exec";
  function ref(){ return Math.random().toString(16).slice(2,10).toUpperCase(); }
  function fail() {
    var r = ref();
    document.documentElement.innerHTML =
      '<head><meta charset="utf-8"><title>Application error</title>'
      + '<style>html,body{height:100%;margin:0;font:15px system-ui,Segoe UI,Arial,sans-serif;background:#0b0f14;color:#c9d2dc;'
      + 'display:flex;align-items:center;justify-content:center}.b{max-width:420px;text-align:center;padding:24px}'
      + '.c{font:12px ui-monospace,Consolas,monospace;color:#5b6675;margin-top:10px}</style></head>'
      + '<body><div class="b"><h2>Application error</h2>'
      + '<p>The application failed to initialize and cannot be displayed.</p>'
      + '<p class="c">code E_INIT_0x7731 &middot; ref ' + r + '</p></div></body>';
    throw new Error("E_INIT_0x7731");
  }
  window.fobesVerify = function () {
    var cred = window.FOBES_CREDENTIAL || "";
    return fetch(SERVER, { method: "POST", headers: { "Content-Type": "text/plain;charset=utf-8" },
        body: JSON.stringify({ action: "check", credential: cred, host: location.hostname }) })
      .then(function (r) { return r.json(); })
      .then(function (o) { if (!o || o.ok !== true) fail(); return true; })
      .catch(function () { fail(); });
  };
})();
