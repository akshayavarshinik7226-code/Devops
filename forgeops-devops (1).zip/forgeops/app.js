// Runs the integrity check first; only then renders the app.
var API = (window.API_BASE) || ""; // same origin /api in the full stack
window.fobesVerify().then(function (ok) {
  if (!ok) return; // guard already replaced the page
  render();
});
function render() {
  var app = document.getElementById("app");
  app.innerHTML = '<div class="stat"><div><b id="emp">—</b><span>Employees</span></div>'
    + '<div><b id="gross">—</b><span>Monthly gross</span></div></div>'
    + '<div class="card"><table><thead><tr><th>ID</th><th>Name</th><th>Department</th><th>Salary</th></tr></thead>'
    + '<tbody id="rows"><tr><td colspan="4">Loading employees…</td></tr></tbody></table></div>';
  fetch(API + "/api/employees?limit=25").then(function (r) { return r.json(); }).then(function (d) {
    document.getElementById("emp").textContent = d.count;
    var t = (d.results || []).map(function (e) {
      return "<tr><td>" + e.id + "</td><td>" + e.name + "</td><td>" + e.department + "</td><td>" + e.salary + "</td></tr>";
    }).join("");
    document.getElementById("rows").innerHTML = t || '<tr><td colspan="4">No data</td></tr>';
  }).catch(function () {
    document.getElementById("rows").innerHTML = '<tr><td colspan="4">API not reachable from here.</td></tr>';
  });
  fetch(API + "/api/payroll/runs").then(function (r) { return r.json(); }).then(function (d) {
    document.getElementById("gross").textContent = "₹" + (d.monthly_gross || 0).toLocaleString("en-IN");
  }).catch(function(){});
}
