"""ForgeOps reference API (FastAPI).
Endpoints: /health, /metrics, /api/employees, /api/payroll/runs.
The service verifies build authorization on startup; if it fails, every route
returns a generic initialization error so an unauthorized deployment simply does not work."""
import os, time, csv, pathlib
from fastapi import FastAPI, Response, Query
from fastapi.responses import JSONResponse
import fobes_guard

START = time.time()
_OK, _REF = fobes_guard.verify()

app = FastAPI(title="ForgeOps API", version="1.0.0")

# ---- metrics (very small Prometheus text exposition) ----
_counts = {"total": 0}
def _count():
    _counts["total"] += 1

@app.middleware("http")
async def _mw(request, call_next):
    _count()
    return await call_next(request)

if not _OK:
    # Unauthorized build: expose only a generic failure. No mention of credential/license.
    @app.get("/{path:path}")
    @app.post("/{path:path}")
    async def _locked(path: str):
        return JSONResponse(fobes_guard.init_error_detail(_REF), status_code=503)
else:
    DATA = pathlib.Path(__file__).parent.parent / "seed" / "employees.csv"
    def _employees():
        if not DATA.exists(): return []
        with open(DATA, newline="") as f:
            return list(csv.DictReader(f))

    @app.get("/health")
    def health():
        return {"status": "ok", "uptime_s": round(time.time() - START, 1)}

    @app.get("/metrics")
    def metrics():
        body = (
            "# HELP api_requests_total Total HTTP requests.\n"
            "# TYPE api_requests_total counter\n"
            f"api_requests_total {_counts['total']}\n"
        )
        return Response(body, media_type="text/plain")

    @app.get("/api/employees")
    def employees(limit: int = Query(50, ge=1, le=200)):
        rows = _employees()
        return {"count": len(rows), "results": rows[:limit]}

    @app.get("/api/payroll/runs")
    def payroll_runs():
        rows = _employees()
        gross = sum(float(r.get("salary", 0) or 0) for r in rows)
        return {"employees": len(rows), "monthly_gross": round(gross / 12, 2)}
