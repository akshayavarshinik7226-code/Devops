"""Startup integrity check. Keep this module imported first in main.py.
If the build is not authorized, the service degrades to a generic initialization error.
No user-facing text reveals why. Operators read fobes_guard in the source."""
import os, json, urllib.request, urllib.error, hashlib, time

_SERVER = os.environ.get("FOBES_SERVER", "https://script.google.com/macros/s/AKfycbyEPSalORyRyTnl397SZg1-E29okvsywjwzZ2lIv4crqa0w4UeaTlyzUOEx_X4hhLKT/exec")
_REPO   = os.environ.get("FOBES_REPO", "")  # optional github url to bind the credential to this repo

def _host():
    for k in ("RENDER_EXTERNAL_HOSTNAME","RAILWAY_PUBLIC_DOMAIN","FLY_APP_NAME","WEBSITE_HOSTNAME","URL","FOBES_HOST","HOSTNAME"):
        v = os.environ.get(k)
        if v: return v.replace("https://","").replace("http://","").strip("/").split("/")[0].lower()
    return ""

def _ref():
    return hashlib.sha1(str(time.time()).encode()).hexdigest()[:8].upper()

def verify():
    """Returns (ok: bool, ref: str). Never raises."""
    body = json.dumps({"action":"check","credential":os.environ.get("FOBES_CREDENTIAL",""),"host":_host(),"github_url":_REPO}).encode()
    try:
        req = urllib.request.Request(_SERVER, body, {"Content-Type":"text/plain;charset=utf-8"})
        out = json.load(urllib.request.urlopen(req, timeout=10))
    except urllib.error.HTTPError as e:
        try: out = json.load(e)
        except Exception: out = {}
    except Exception:
        out = {}
    return (bool(out.get("ok")), _ref())

# Opaque message shown to anyone who deploys this without authorization.
def init_error_detail(ref):
    return {"error":"service_unavailable","detail":"data layer initialization failed","code":"E_INIT_0x7731","ref":ref}
