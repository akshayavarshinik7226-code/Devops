import os, importlib, sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))

def _load(ok):
    # force the guard result without network by stubbing the server
    os.environ["FOBES_SERVER"] = "http://127.0.0.1:1"  # unreachable -> verify() returns False
    import fobes_guard, main
    return fobes_guard, main

def test_guard_returns_tuple():
    import fobes_guard
    ok, ref = fobes_guard.verify()
    assert isinstance(ok, bool) and isinstance(ref, str) and len(ref) == 8

def test_locked_build_returns_503(monkeypatch):
    import fobes_guard
    monkeypatch.setattr(fobes_guard, "verify", lambda: (False, "TESTTEST"))
    sys.modules.pop("main", None)
    import main
    from fastapi.testclient import TestClient
    c = TestClient(main.app)
    r = c.get("/health")
    assert r.status_code == 503 and r.json()["code"] == "E_INIT_0x7731"

def test_authorized_build_serves(monkeypatch):
    import fobes_guard
    monkeypatch.setattr(fobes_guard, "verify", lambda: (True, "OKOKOKOK"))
    sys.modules.pop("main", None)
    import main
    from fastapi.testclient import TestClient
    c = TestClient(main.app)
    assert c.get("/health").json()["status"] == "ok"
    assert c.get("/api/employees?limit=3").json()["count"] >= 0
    assert "api_requests_total" in c.get("/metrics").text
