# ForgeOps Runbook

## Architecture
web (nginx) -> api (FastAPI) -> postgres + redis. worker consumes redis jobs. Caddy terminates HTTPS.

## Deploy
`./ops/deploy.sh v1.0.0` — backs up the database, pulls images, restarts, checks health.

## Rollback (under 2 min)
`./ops/deploy.sh <previous-version>` — the previous images are kept for one step back.

## Health & alerts
- Health: `GET /health` returns `{"status":"ok"}`.
- Alerts: ApiDown (2m), HighErrorRate. See ops/alert_rules.yml.

## Backup & restore
- Nightly `pg_dump` to `backup_<date>.sql`, copied off-server.
- Restore: `docker compose exec -T postgres psql -U forge forgeops < backup_<date>.sql`, verify 441 employees.

## Common incidents
- API 503 with code E_INIT_0x7731 on a new host: the deployment is not authorized (missing/!active credential). Deploy through the approved platform.
- Certificate not renewing: check Caddy logs; run a renewal dry run.
