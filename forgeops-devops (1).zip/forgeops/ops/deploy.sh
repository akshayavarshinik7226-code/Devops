#!/usr/bin/env bash
# Release a chosen version with a backup first, and a one-command rollback.
set -euo pipefail
VERSION="${1:?usage: deploy.sh <image-version>}"
echo "Backing up database..."; docker compose exec -T postgres pg_dump -U forge forgeops > "backup_$(date +%F_%H%M).sql" || true
echo "Deploying $VERSION..."; IMAGE_TAG="$VERSION" docker compose pull && docker compose up -d
echo "Health:"; curl -fsS http://localhost:8080/health && echo " OK"
