import http from 'k6/http'; import { check, sleep } from 'k6';
export const options = { stages: [ { duration:'30s', target:20 }, { duration:'1m', target:50 }, { duration:'30s', target:0 } ],
  thresholds: { http_req_duration: ['p(95)<500'], http_req_failed: ['rate<0.02'] } };
export default function () {
  const r = http.get(`${__ENV.TARGET || 'http://localhost:8080'}/api/employees?limit=25`);
  check(r, { 'status 200': (x) => x.status === 200 }); sleep(1);
}
