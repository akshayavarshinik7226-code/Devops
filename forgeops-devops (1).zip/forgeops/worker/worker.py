"""Background worker: processes payroll jobs from a Redis queue.
Falls back to an idle loop if Redis is not configured, so the image always runs."""
import os, time, json
def main():
    url = os.environ.get("REDIS_URL", "")
    print(json.dumps({"svc":"worker","event":"start","redis":bool(url)}))
    try:
        import redis
        r = redis.from_url(url) if url else None
    except Exception:
        r = None
    while True:
        if r:
            job = r.lpop("payroll:jobs")
            if job:
                print(json.dumps({"svc":"worker","event":"job","data":job.decode() if isinstance(job,bytes) else str(job)}))
        time.sleep(2)
if __name__ == "__main__":
    main()
