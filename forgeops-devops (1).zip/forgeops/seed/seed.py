"""Seed helper. In the full stack this loads employees.csv into PostgreSQL.
Here it validates the dataset so `python seed/seed.py` works with or without a database."""
import csv, os, pathlib
CSV = pathlib.Path(__file__).parent / "employees.csv"
def main():
    rows = list(csv.DictReader(open(CSV)))
    print(f"seed: {len(rows)} employees ready")
    url = os.environ.get("DATABASE_URL")
    if not url:
        print("seed: DATABASE_URL not set, validation only"); return
    try:
        import psycopg
        with psycopg.connect(url) as c:
            c.execute("CREATE TABLE IF NOT EXISTS employees(id int primary key, name text, department text, salary numeric)")
            for r in rows:
                c.execute("INSERT INTO employees VALUES(%s,%s,%s,%s) ON CONFLICT (id) DO NOTHING",
                          (r["id"], r["name"], r["department"], r["salary"]))
        print("seed: loaded into PostgreSQL")
    except Exception as e:
        print("seed: database step skipped:", e)
if __name__ == "__main__":
    main()
