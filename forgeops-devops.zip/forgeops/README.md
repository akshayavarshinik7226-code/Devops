# ForgeOps — DevOps Track reference project

A complete, containerised workforce platform: a FastAPI **API**, a background **worker**, an nginx-served **web** app, **PostgreSQL** and **Redis**, with CI, monitoring, HTTPS, backups and a release process. One command runs the whole stack.

```bash
cp .env.example .env     # fill in FOBES_CREDENTIAL and POSTGRES_PASSWORD
docker compose up --build
# open http://localhost:8080
```

## What runs where
- `api/` — FastAPI. Endpoints: `/health`, `/metrics`, `/api/employees`, `/api/payroll/runs`. Non-root image, healthcheck.
- `worker/` — consumes payroll jobs from Redis.
- `web/` — static front end served by nginx; `/api` is proxied to the API. Deployable to a static host on its own.
- `seed/` — 441 fictional employees (`employees.csv`) + `seed.py` loader.
- `ops/` — Caddy (HTTPS), Prometheus + alerts, Grafana provisioning, `deploy.sh` (release + rollback), k6 load test, runbook.
- `.github/workflows/ci.yml` — tests the API, then builds the images.

## The 20 tasks, mapped to this repo
**Phase 1 — Foundation**
1. Containerise API & worker → `api/Dockerfile`, `worker/Dockerfile` (slim, non-root, healthcheck, `.dockerignore` via `.gitignore`).
2. Web multi-stage / nginx serve → `web/Dockerfile`, `web/nginx.conf`.
3. Compose the five services → `docker-compose.yml` (volumes, healthchecks, start order; DB/Redis not published).
4. Config & secrets → `.env.example`, `.gitignore` (no secrets in git or images).
5. Git workflow & protected main → branch protection + PR template (set on the GitHub repo).

**Phase 2 — Pipeline & server**
6. CI on every PR → `.github/workflows/ci.yml` (API tests).
7. Security & quality gates → add Ruff/pip-audit/Trivy/Gitleaks/Hadolint steps to CI.
8. Versioned images in a registry → CI `images` job builds API & web; tag and push to ghcr.io.
9. Provision & harden a server → see `ops/RUNBOOK.md`.
10. Infrastructure as code → Terraform/Ansible in a sibling `forgeops-infra` repo.

**Phase 3 — Run it properly**
11. Reverse proxy & HTTPS → `ops/Caddyfile` (auto Let's Encrypt, HSTS).
12. Database backups → `ops/deploy.sh` backup step; restore in `ops/RUNBOOK.md`.
13. Metrics (Prometheus/Grafana) → `/metrics`, `ops/prometheus.yml`, `ops/grafana/`.
14. Centralised logging → services print JSON logs (add Loki/Promtail).
15. Alerting & status page → `ops/alert_rules.yml`.

**Phase 4 — Release**
16. Staging & rollback → `ops/deploy.sh` (backup, deploy, one-step rollback).
17. Production release by pipeline → CI + approval environment.
18. Disaster recovery drill → `ops/RUNBOOK.md`.
19. Load testing & tuning → `ops/k6_load_test.js` (p95 < 500ms, error < 2%).
20. Runbook, architecture & handover → `ops/RUNBOOK.md`, Mermaid diagram, v1.0.0 tag.

## Build authorization
This project verifies its build on startup (`api/fobes_guard.py`, `web/fobes_guard_client.js`). It needs an active credential, provided as `FOBES_CREDENTIAL`, checked against the authorization server.

- Authorized build → the API and web app run normally.
- Unauthorized build (no/!active credential — e.g. deployed to an outside host without it) → the service does not start properly: the API returns a generic `503` initialization error (`code E_INIT_0x7731`) and the web app shows a generic "Application error". Nothing names the reason.

Set `FOBES_CREDENTIAL` (and `FOBES_SERVER`) via the platform's environment, never commit it.

## Tests
```bash
cd api && pip install -r requirements.txt && FOBES_SERVER=http://127.0.0.1:1 pytest -q
```
Covers the guard, the locked-build 503, and the authorized build serving data.
